# Personal Daily Life Planner — Android project

ဒီဖိုင်သည် Android Studio ဖြင့် APK build လုပ်ရန် source project ဖြစ်သည်။ APK ဖိုင်ကို ကြိုတင် build လုပ်ပြီးသား မဟုတ်ပါ။

## လိုအပ်ချက်
- Computer (Windows / macOS / Linux)
- Android Studio (တည်ငြိမ်သော version)
- Android SDK Platform 35 နှင့် JDK 17 (Android Studio က သတ်မှတ်ပေးနိုင်သည်)
- ပထမအကြိမ် Gradle sync အတွက် internet

## APK ထုတ်လုပ်နည်း
1. ZIP ကို computer ပေါ်မှာ extract လုပ်ပါ။
2. Android Studio ဖွင့်ပြီး **Open** ကိုနှိပ်ပါ။
3. Extract လုပ်ထားသော `PersonalDailyPlannerAndroid` folder ကို ရွေးပါ။
4. Gradle sync ပြီးဆုံးသည်အထိ စောင့်ပါ။ SDK ပျောက်နေပါက Android Studio က ပြသသည့် SDK ကို install လုပ်ပါ။
5. စမ်းသပ် APK ထုတ်ရန် **Build > Build Bundle(s) / APK(s) > Build APK(s)** ကိုနှိပ်ပါ။
6. Build အောင်မြင်လျှင် APK သည် `app/build/outputs/apk/debug/app-debug.apk` တွင် ရှိမည်။
7. APK ကို Android ဖုန်းသို့ ကူးပြီး install လုပ်ပါ။ ဖုန်းက ခွင့်ပြုချက်တောင်းလျှင် ယုံကြည်ရသော APK အတွက်သာ ခွင့်ပြုပါ။

## သတိပြုရန်
- ဒီ project သည် WebView wrapper သုံးထားသည်။
- လုပ်စရာ၊ ငွေကြေးနှင့် reflection များကို WebView localStorage ထဲတွင် သိမ်းသည်။ App data clear လုပ်ခြင်း သို့မဟုတ် app uninstall လုပ်ခြင်းဖြင့် data ပျောက်နိုင်သည်။
- Cloud sync / login / backup မပါဝင်သေးပါ။
- Play Store ထုတ်ဝေရန် release signing၊ privacy policy နှင့် လိုအပ်သော policy checks များ ထပ်လုပ်ရမည်။
- SDK/Gradle version လိုအပ်ချက်များကို Android Studio မှာ ပြသသည့်အတိုင်း ညှိပါ။
